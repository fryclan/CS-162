You will need the spells.py, player_character.py, and the adventure_class.py files it will created a txt document that has the output

to Run:
run the player_character.py in vscode